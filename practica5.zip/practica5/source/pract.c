#include <stdio.h>
#include "MKL25Z4.h"

void pinMode(unsigned char ubPort, unsigned int ubPin,unsigned char ubMode);
void digitalWrite( unsigned char ubPort,unsigned int ubPin, unsigned char ubMode);

void led (void){

	uint32_t t;


	//LED VERDE
	PORTB->PCR[19]|=1<<8; //Se declara el puerto B pin 19 como GPIO (PCR= Pin Control Register)
	GPIOB->PDDR|=1<<19; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	GPIOB->PCOR|=0<<19; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
	GPIOB->PTOR |=1<<19; //invierte (PTOR= Port Toggle Output Register)

	//LED ROJO
	PORTB->PCR[18]|=1<<8; //Se declara el puerto B pin 19 como GPIO (PCR= Pin Control Register)
	GPIOB->PDDR|=1<<18; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	GPIOB->PCOR|=0<<18; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
	GPIOB->PTOR |=1<<18; //invierte (PTOR= Port Toggle Output Register)

	//LED AZUL
	PORTD->PCR[1]|=1<<8; //Se declara el puerto B pin 19 como GPIO (PCR= Pin Control Register)
	GPIOD->PDDR|=1<<1; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	GPIOD->PCOR|=0<<1; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
	GPIOD->PTOR |=1<<1; //invierte (PTOR= Port Toggle Output Register)


}

void pinMode(unsigned char ubPort, unsigned int ubPin,unsigned char ubMode){
	SIM->SCGC5|= SIM_SCGC5_PORTA_MASK; //Activa la señal de reloj del puerto A
	SIM->SCGC5|= SIM_SCGC5_PORTB_MASK; //Activa la señal de reloj del puerto B
	SIM->SCGC5|= SIM_SCGC5_PORTC_MASK; //Activa la señal de reloj del puerto C
	SIM->SCGC5|= SIM_SCGC5_PORTD_MASK; //Activa la señal de reloj del puerto D
	SIM->SCGC5|= SIM_SCGC5_PORTE_MASK; //Activa la señal de reloj del puerto E

	switch(ubPort){
	case 'A':
		PORTA->PCR[ubPin]|= 1<<8; //8 por el gpio
		GPIOA->PDDR|=ubMode<<ubPin; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'B':
		PORTB->PCR[ubPin]|= 1<<8; //8 por el gpio
		GPIOB->PDDR|=ubMode<<ubPin; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'C':
		PORTC->PCR[ubPin]|= 1<<8; //8 por el gpio
		GPIOC->PDDR|=ubMode<<ubPin; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
	break;
	case 'D':
		PORTD->PCR[ubPin]|= 1<<8; //8 por el gpio
		GPIOD->PDDR|=ubMode<<ubPin; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
		break;
	case 'E':
		PORTE->PCR[ubPin]|= 1<<8; //8 por el gpio
		GPIOE->PDDR|=ubMode<<ubPin; //Se coloca un 1 en el pin 19 para ponerlo como una salida, caso contrario si fuera 0 se configuraría como entrada (PDDR=Port Data Direction Register)
		break;
	}
}

void digitalWrite(unsigned char ubPort,unsigned int ubPin, unsigned char ubMode){
	if(ubMode==0){
	switch(ubPort){
		case 'A':
			GPIOA->PCOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'B':
			GPIOB->PCOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'C':
			GPIOC->PCOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'D':
			GPIOD->PCOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
		case 'E':
			GPIOE->PCOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
	}
	}else{
	switch(ubPort){
		case 'A':
			GPIOA->PTOR|=1<<ubPin; //invierte (PTOR= Port Toggle Output Register)
		break;
		case 'B':
			GPIOB->PTOR|=1<<ubPin; // invierte (PTOR= Port Toggle Output Register)
		break;
		case 'C':
			GPIOC->PTOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
		break;
		case 'D':
			GPIOD->PTOR |=1<<ubPin; //invierte (PTOR= Port Toggle Output Register)
			break;
		case 'E':
			GPIOE->PTOR|=1<<ubPin; // Manda a 0 para encender el LED (funciona con lógica negativa) (PCOR=Port Clear Output Register)
			break;
	}
	}
}

